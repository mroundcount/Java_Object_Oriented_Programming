import java.util.Random;
//import java.util.Arrays;

public class stopWatchTest {
    public static void main(String[] args) {
    	stopWatch watch = new stopWatch();
        int numbers[] = buildRandomNumbers();
        numbers = sort(numbers);
        watch.end_timer();
        System.out.println("Total sort time: " + watch.getElapsed() + "ms");
    }

    private static int[] buildRandomNumbers(){
    	Random g = new Random();

        int [] numbers = new int [10000];

        for (int d = 0 ; d<numbers.length ; d++){
            int RandomG = g.nextInt(10000)+1;
            numbers[d] = RandomG;
            }
		return numbers;   
    } 

    private static int[] sort(int numbers[]) {
    	int temp;

        for(int i = 0 ; i < numbers.length-1 ; i++){
            for ( int j = 1 ; j < numbers.length-i-1 ; j++){
                if ( numbers[j-1] > numbers[j]){
                    temp = numbers[j-1];
                    numbers[j-1] = numbers[j];
                    numbers[j] = temp;
                }
            }
        }
		return numbers;
    	
    }
}