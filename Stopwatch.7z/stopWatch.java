//import java.time.LocalTime;
//import java.time.Duration;

public class stopWatch {
    private long startClock = 0l;
    private long endClock = 0l;

    private static long currentTime() {
        return System.currentTimeMillis();
    }

    public stopWatch() {
        startClock = currentTime();
    }

    public long getStartClock() {
        return startClock;
    }

    public long getEndClock() {
        return endClock;
    }

    public void start_timer() {
        startClock = currentTime();
    }

    public void end_timer() {
        endClock = currentTime();
    }

    public long getElapsed() {
        return (endClock != 0l) ? endClock - startClock : 0l;
    }
}
