//Child class for the Scanner

//When you implement you are going to use "extends"
public class Scanner extends Machine {
	
	//Scanner 2 lbs � 25 lbs Default: 10 lbs 
	//$60-$300 inclusive Default: $80 

	 @Override
	    public void setWeight(double weight) {
	        if(weight >= 2 && weight <= 25) {
	            this.weight = weight;
	        } else {
	            this.weight = 10;
	        }
	    }
	
	@Override
    public void setPrice(double price) {
        if(price >= 60 && price <= 300) {
            this.price = price;
        } else {
            this.price = 80;
        }
    }
  
}