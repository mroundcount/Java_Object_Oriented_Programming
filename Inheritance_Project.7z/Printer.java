//Child class for the printer

//When you implement you are going to use "extends"
public class Printer extends Machine {

//Printer Less than 50 lbs Default: 25 lbs 
//$40-$200 inclusive Default: $90
	
	@Override
    public void setWeight(double weight) {
        if(weight <= 50) {
            this.weight = weight;
        } else {
            this.weight = 25;
        }
    }   
	
	@Override
    public void setPrice(double price) {
        if(price >= 40 && price <= 200) {
            this.price = price;
        } else {
            this.price = 90;
        }
    }

    
}