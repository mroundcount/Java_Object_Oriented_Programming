//Creating the abstract class
public abstract class Machine {
//defining the variables for the methods to be used by each child class
	
	//Methods to setWeight and setPrice will be abstract and defined in the child class
	//Cannot be implemented in the parent class
	
	//Data fields (protected) begin at the parent level and inherited by the child class

    private String name;
    protected double price;
    protected double weight;
    private String description;

    //Get method for the name
    public String getName() {
        return name;
    }
    //set method for the name
    public void setName(String name) {
        this.name = name;
    }
    //get method for the price
    public double getPrice() {
        return price;
    }
    //set method for the price
    public abstract void 
    	setPrice(double price);
    
    //get method for the weight
    public double getWeight() {
        return weight;
    }
    //set method for the weight
    public abstract void 
    	setWeight(double weight);

    //get method for the desciption
    public String getDescription() {
        return description;
    }
    //set method for the description
    public void setDescription(String description) {
        this.description = description;
    }
}